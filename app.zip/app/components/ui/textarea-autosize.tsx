import TextareaAutosize from "react-textarea-autosize"

export { TextareaAutosize }

export const AuthStrategies = {
  FORM: "form",
  GOOGLE: "google",
  GITHUB: "github",
} as const

import parseHTML from "html-react-parser"

export { parseHTML }

export type PageStatusSymbol = "DRAFT" | "PUBLISHED"

export type PostStatusSymbol = "DRAFT" | "PRIVATE" | "UNLISTED" | "PUBLISHED" | "ARCHIVED"

export const configUserDashboard = {
  navItems: [{ to: "/user/posts", text: "Posts", isMetric: true }],
}
